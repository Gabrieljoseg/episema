# Episema

A Python library for rendering Gregorian Chant in square note notation.

**Episema** is a Python twin of the [exsurge](https://github.com/frmatthew/exsurge) JavaScript library, designed to parse and render Gregorian chant notation.

## Installation

```bash
pip install episema
```

## Features

- Parse GABC (Gregorio) notation
- Render Gregorian chant in square note notation
- Support for various chant elements (neumes, clefs, lyrics, etc.)
- Extensible architecture for custom rendering

## Usage

```python
from episema import ChantScore

# Create a chant score from GABC notation
gabc = "c4 c(e) d(f) e(g)"
score = ChantScore.from_gabc(gabc)

# Render to SVG
svg_output = score.render()
```

## Development

This project uses [Poetry](https://python-poetry.org/) for dependency management.

### Setup Development Environment

```bash
# Clone the repository
git clone https://github.com/yourusername/episema.git
cd episema

# Install dependencies
poetry install

# Activate virtual environment
poetry shell
```

### Running Tests

```bash
poetry run pytest
```

## Publishing to PyPI

This package uses Poetry for building and publishing. Follow these steps to publish to PyPI:

### Prerequisites

1. **Create a PyPI account** at [https://pypi.org/account/register/](https://pypi.org/account/register/)
2. **Create an API token** at [https://pypi.org/manage/account/token/](https://pypi.org/manage/account/token/)
   - Give it a descriptive name (e.g., "episema-upload")
   - Set the scope to "Entire account" or limit to this project once it exists

### Publishing Steps

#### 1. Configure PyPI Credentials

```bash
# Add PyPI repository (optional, PyPI is default)
poetry config repositories.pypi https://upload.pypi.org/legacy/

# Configure your API token
poetry config pypi-token.pypi pypi-YOUR_API_TOKEN_HERE
```

#### 2. Update Version

Update the version in `pyproject.toml`:

```toml
[project]
version = "0.1.0"  # Update this before publishing
```

Or use Poetry's version command:

```bash
# Bump patch version (0.1.0 -> 0.1.1)
poetry version patch

# Bump minor version (0.1.0 -> 0.2.0)
poetry version minor

# Bump major version (0.1.0 -> 1.0.0)
poetry version major

# Set specific version
poetry version 1.2.3
```

#### 3. Build the Package

```bash
# Build both wheel and source distributions
poetry build
```

This creates files in the `dist/` directory:
- `episema-0.1.0-py3-none-any.whl` (wheel distribution)
- `episema-0.1.0.tar.gz` (source distribution)

#### 4. Publish to PyPI

```bash
# Publish to PyPI
poetry publish
```

Or combine build and publish:

```bash
poetry publish --build
```

#### 5. Verify Publication

Visit [https://pypi.org/project/episema/](https://pypi.org/project/episema/) to see your published package.

### Publishing to TestPyPI (Recommended First)

Before publishing to the main PyPI, test with TestPyPI:

```bash
# Add TestPyPI repository
poetry config repositories.testpypi https://test.pypi.org/legacy/

# Get a token from https://test.pypi.org/manage/account/token/
poetry config pypi-token.testpypi pypi-YOUR_TEST_API_TOKEN_HERE

# Publish to TestPyPI
poetry publish -r testpypi --build

# Test installation from TestPyPI
pip install --index-url https://test.pypi.org/simple/ episema
```

### Troubleshooting

- **Version already exists**: Increment the version number in `pyproject.toml`
- **Authentication failed**: Verify your API token is correct
- **Build fails**: Run `poetry check` to validate `pyproject.toml`

## License

MIT License - See LICENSE file for details

## Credits

Inspired by [exsurge](https://github.com/frmatthew/exsurge) by Fr. Matthew Spencer, O.S.J.

## Keywords

gregorian, chant, square note, solesmes, gabc, liturgy, music notation
